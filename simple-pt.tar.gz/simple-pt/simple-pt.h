

#define SIMPLE_PT_SET_CPU 9901 /* arg: cpu number */
#define SIMPLE_PT_GET_SIZE 9902 /* arg: pointer to int, output for buffer size */
#define SIMPLE_PT_GET_OFFSET 9903 /* arg: pointer to int, last write offset in buffer */
			     /* must be stopped */
