struct pt_image;

void read_kernel(struct pt_image *);
