this is not a dependence driven build.
it is for testing various msvs environments.
